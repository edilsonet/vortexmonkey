declare module 'rconta/App' { const App: import('react').ComponentType; export default App; }
declare module 'catalogo/App' { const App: import('react').ComponentType; export default App; }
declare module 'rloja/App' { const App: import('react').ComponentType; export default App; }
declare module 'recrutamento/App' { const App: import('react').ComponentType; export default App; }
declare module 'mro/App' { const App: import('react').ComponentType; export default App; }
declare module 'ops/App' { const App: import('react').ComponentType; export default App; }
declare module 'training/App' { const App: import('react').ComponentType; export default App; }
declare module 'airport/App' { const App: import('react').ComponentType; export default App; }
