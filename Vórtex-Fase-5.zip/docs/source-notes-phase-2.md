# Notas de fonte — Fase 2

## IS 43.9-004A

Fonte local preservada na entrega: `docs/sources/IS_43.9-004A.pdf`.

A IS estabelece procedimentos mínimos para sistemas eletrônicos que substituem registros em papel. A fundamentação cita a Resolução ANAC 458/2017 e informa que a Resolução 511/2019 passou a permitir blockchain, com possíveis adaptações de procedimento.

Os requisitos de registros físicos continuam aplicáveis ao meio digital. O sistema deve preservar conteúdo, forma, disposição, transferência, falsificação e retenção previstos nos regulamentos aplicáveis. Documento eletrônico deve permanecer com conteúdo idêntico em qualquer dispositivo e deve ser exibido com clareza e legibilidade.

A IS distingue documento, registro e dados significativos. Registro errôneo ou irregular deve ser identificado como inválido, conservado e substituído por outro registro corrigido ou regularizado que referencie o número de controle original. Legibilidade é indispensável para certificação e fiscalização.

O sistema deve identificar os responsáveis pela execução, inspeção, aprovação de ação corretiva e aprovação para retorno ao serviço, com código ANAC e assinatura eletrônica quando aplicável. O operador deve assegurar que todas as pessoas que assinam estejam cadastradas no sistema.

As fontes canônicas do pacote do usuário definem, para a Parte 2, ledger append-only, protocolo AAAA-NNNNNN, níveis `PUBLIC`, `RESTRICTED` e `PRIVATE`, timeline imutável, prazos de vista de 5 e 10 dias e verificação diária do ledger. Não foram encontrados arquivos locais com nomes de Resolução 458 ou 520; a IS 43.9-004A e os arquivos Markdown canônicos permanecem as fontes anexadas disponíveis.
## Requisitos adicionais — páginas 6 a 8

A impressão de informação eletrônica deve identificar data, hora e versão, para permitir comparação com a versão atual. O regulado é responsável pela guarda, pelos meios de registro e pelo acesso quando necessário.

A IS estabelece prazo de até 30 dias corridos após o retorno ao serviço para registrar e assinar digitalmente os dados autorizados no SDRMe. Quando um tipo de registro digital é autorizado, o formato digital torna-se oficial e novos registros em papel não devem ser usados.

Os manuais do regulado devem conter políticas, procedimentos operacionais, sequência de assinaturas e treinamento dos usuários. A sequência envolve executor, inspetor, aprovador de ação corretiva e aprovador para retorno ao serviço, conforme aplicável.

Registros transferidos, inclusive os oriundos de manutenção terceirizada, devem conservar os requisitos regulamentares. Documentos eletrônicos exigem controle de revisão, descarte de impressões desatualizadas, arquivamento de versões anteriores e possibilidade de regeneração, duplicação ou reconstrução.

A autorização do SDRMe deve identificar tipos de documentos, manuais revisados, sistemas, equipamentos e contingências. A ANAC pode auditar o sistema e deve ter demonstração de equipamentos, acessos, funções e operação. A guarda continua obrigatória após descontinuação integral ou parcial do SDRMe.
