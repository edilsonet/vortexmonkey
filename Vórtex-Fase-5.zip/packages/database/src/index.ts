export const DATABASE_SCHEMAS = [
  'identity', 'ledger', 'protocol', 'documents', 'catalog',
  'subscriptions', 'oauth', 'signatures', 'compliance', 'notifications'
] as const;
