# VORTEX — Parte 1/8

**Fundação, Shell Unificada, Design System e Núcleo de Identidade (MDM)**

Esta entrega implementa a primeira parte executável do VORTEX como **monólito modular**, com frontend composto por oito remotes federados. O sistema inclui autenticação JWT, contexto multi-tenant protegido por Row-Level Security (RLS), MDM de pessoas, vínculos, licenças e credenciamentos, ledger append-only assinado com Ed25519, outbox transacional, Redis, RabbitMQ, MinIO, Prometheus e PostgreSQL 16.

![Shell Rconta](docs/shell-rconta.png)

## Início rápido

Pré-requisitos: Docker com Compose v2. O ambiente gera segredos aleatórios em um volume Docker na primeira inicialização. Nenhum segredo é versionado.

```bash
docker compose up -d --build
```

O estado dos serviços pode ser verificado com:

```bash
curl http://localhost:3000/health
docker compose ps
```

Para criar uma credencial exclusivamente local, defina uma senha com pelo menos 12 caracteres sem gravá-la em arquivo versionado:

```bash
docker compose run --rm \
  -e VORTEX_DEV_PASSWORD='substitua-por-uma-senha-local-forte' \
  migrate pnpm db:seed:dev
```

O login de desenvolvimento usa `admin@vortex.local`. A senha é a fornecida no comando anterior.

| Superfície | Endereço local |
|---|---|
| API e health | `http://localhost:3000` |
| Rconta | `http://rconta.vortex.localhost:8080` |
| Catálogo Central | `http://catalogo.vortex.localhost:8080` |
| RLoja | `http://market.vortex.localhost:8080` |
| Recrutamento | `http://recruta.vortex.localhost:8080` |
| ERP 43+145 | `http://mro.vortex.localhost:8080` |
| ERP Operadores | `http://ops.vortex.localhost:8080` |
| ERP 141/142 | `http://training.vortex.localhost:8080` |
| ERP 153 | `http://airport.vortex.localhost:8080` |

## Estrutura

| Diretório | Responsabilidade |
|---|---|
| `apps/api` | Backend NestJS modular, autenticação, MDM, ledger, outbox, health e métricas |
| `apps/shell` | Host React 19 de Module Federation e navegação unificada |
| `apps/{rconta,...,airport}` | Oito remotes federados isolados |
| `packages/ui-core` | Design System versionado, tokens, componentes e logomarca SVG |
| `packages/contracts-fe` | Registro de aplicativos, rotas e navegação por subdomínio |
| `packages/contracts-be` | Enums controlados, eventos e seeds regulatórios da Parte 1 |
| `packages/sdk` | Cliente API-first com contexto, JWT e `Idempotency-Key` |
| `packages/database` | Migrations SQL, migrator, seed local e testes RLS |
| `docs/canonical` | Cópia rastreável das fontes recebidas no pacote original |

## Gates de qualidade

```bash
pnpm install --frozen-lockfile
pnpm lint
pnpm typecheck
pnpm test
pnpm test:coverage
pnpm build
pnpm audit --prod --audit-level high
```

A API e a Shell possuem gate de **85% de linhas** nos núcleos determinísticos cobertos. A validação completa também inclui testes SQL de RLS, unicidade do MDM e imutabilidade do ledger.

## Documentação

- [Arquitetura](docs/architecture.md)
- [API e SDK](docs/api.md)
- [Segurança e conformidade](docs/security-and-compliance.md)
- [Runbook local](docs/runbook.md)
- [Status da Parte 1](docs/phase-1-status.md)
- [Decisões arquiteturais](docs/decisions.md)

## Referências

[1]: docs/canonical/prompts/parte-1.md "VORTEX — Parte 1/8: Fundação, Shell Unificada, Design System e Núcleo de Identidade"
[2]: docs/canonical/07-delimitacao.md "Delimitação e precedência das fontes canônicas"
