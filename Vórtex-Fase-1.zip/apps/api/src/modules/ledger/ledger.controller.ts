import { Controller, Get, Req } from '@nestjs/common';
import type { Request } from 'express';
import { LedgerService } from './ledger.service';

@Controller('api/v1/ledger')
export class LedgerController {
  public constructor(private readonly ledger: LedgerService) {}
  @Get('verify') public verify(@Req() request: Request) { return this.ledger.verifyChain(request.vortexContext!); }
}
