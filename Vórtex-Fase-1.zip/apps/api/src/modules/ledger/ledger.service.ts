import { Injectable } from '@nestjs/common';
import { createHash, createPublicKey, generateKeyPairSync, sign, verify as verifySignature } from 'node:crypto';
import { readFileSync } from 'node:fs';
import type { RequestContext } from '@vortex/types';
import { stableStringify } from '@vortex/utils';
import { DatabaseService, type SqlClient } from '../../platform/database/database.service';

export interface AppendLedgerInput { id: string; entityType: string; entityId: string; actionType: string; payload: unknown; changes?: unknown }
interface LedgerRow { id: string; previous_hash: string; hash: string; entity_type: string; entity_id: string; action_type: string; payload: unknown; signature: string }

@Injectable()
export class LedgerService {
  public constructor(private readonly database: DatabaseService) {}
  private readonly privateKey = (() => {
    const path = process.env.LEDGER_PRIVATE_KEY_FILE;
    if (path) return readFileSync(path, 'utf8');
    if (process.env.NODE_ENV === 'production') throw new Error('LEDGER_PRIVATE_KEY_FILE é obrigatório em produção.');
    return generateKeyPairSync('ed25519').privateKey;
  })();
  private readonly publicKey = process.env.LEDGER_PUBLIC_KEY_FILE ? readFileSync(process.env.LEDGER_PUBLIC_KEY_FILE, 'utf8') : createPublicKey(this.privateKey);

  public async append(client: SqlClient, context: RequestContext, input: AppendLedgerInput): Promise<string> {
    await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [context.tenantId]);
    const previous = await client.query<{ hash: string }>('SELECT hash FROM ledger.ledger_blocks WHERE tenant_id = $1 ORDER BY timestamp DESC LIMIT 1', [context.tenantId]);
    const previousHash = previous.rows[0]?.hash ?? '0'.repeat(64);
    const canonical = [previousHash, input.entityType, input.entityId, input.actionType, stableStringify(input.payload)].join('|');
    const hash = createHash('sha256').update(canonical).digest('hex');
    const signature = sign(null, Buffer.from(hash, 'hex'), this.privateKey).toString('base64');
    await client.query(`INSERT INTO ledger.ledger_blocks(id, previous_hash, hash, tenant_id, user_id, company_id, entity_type, entity_id, action_type, payload, changes, created_by, signature)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,$11::jsonb,$5,$12)`, [input.id, previousHash, hash, context.tenantId, context.userId, context.companyId ?? null, input.entityType, input.entityId, input.actionType, JSON.stringify(input.payload), JSON.stringify(input.changes ?? null), signature]);
    return hash;
  }

  public verifyChain(context: RequestContext): Promise<{ valid: boolean; totalBlocks: number; lastHash: string; issues: string[] }> {
    return this.database.withContext(context, async (client) => {
      const result = await client.query<LedgerRow>(`SELECT id,previous_hash,hash,entity_type,entity_id,action_type,payload,signature FROM ledger.ledger_blocks WHERE tenant_id=$1 ORDER BY timestamp,id`, [context.tenantId]);
      let expectedPrevious = '0'.repeat(64);
      const issues: string[] = [];
      for (const block of result.rows) {
        const canonical = [block.previous_hash, block.entity_type, block.entity_id, block.action_type, stableStringify(block.payload)].join('|');
        const recomputed = createHash('sha256').update(canonical).digest('hex');
        if (block.previous_hash !== expectedPrevious) issues.push(`${block.id}: previous_hash divergente`);
        if (block.hash !== recomputed) issues.push(`${block.id}: hash divergente`);
        if (!verifySignature(null, Buffer.from(block.hash, 'hex'), this.publicKey, Buffer.from(block.signature, 'base64'))) issues.push(`${block.id}: assinatura Ed25519 inválida`);
        expectedPrevious = block.hash;
      }
      return { valid: issues.length === 0, totalBlocks: result.rows.length, lastHash: expectedPrevious, issues };
    });
  }
}
