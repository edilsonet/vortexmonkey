import type { ApiResponse } from '@vortex/types';

export interface VortexClientOptions {
  baseUrl: string;
  accessToken?: () => string | undefined;
  fetcher?: typeof fetch;
}

export class VortexClient {
  readonly #fetcher: typeof fetch;
  readonly #baseUrl: string;
  readonly #accessToken: () => string | undefined;

  public constructor(options: VortexClientOptions) {
    this.#fetcher = options.fetcher ?? fetch;
    this.#baseUrl = options.baseUrl.replace(/\/$/, '');
    this.#accessToken = options.accessToken ?? (() => undefined);
  }

  public async request<T>(path: string, init: RequestInit = {}): Promise<ApiResponse<T>> {
    const headers = new Headers(init.headers);
    headers.set('accept', 'application/json');
    const token = this.#accessToken();
    if (token) headers.set('authorization', `Bearer ${token}`);
    if (init.body && !headers.has('content-type')) headers.set('content-type', 'application/json');
    if (init.method && !['GET', 'HEAD'].includes(init.method.toUpperCase()) && !headers.has('idempotency-key')) {
      headers.set('idempotency-key', crypto.randomUUID());
    }
    const response = await this.#fetcher(`${this.#baseUrl}${path}`, { ...init, headers });
    return response.json() as Promise<ApiResponse<T>>;
  }

  public health(): Promise<ApiResponse<{ status: 'ok' }>> { return this.request('/health'); }
  public me(): Promise<ApiResponse<unknown>> { return this.request('/api/v1/identity/me'); }
}
